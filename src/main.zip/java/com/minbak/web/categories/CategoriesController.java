package com.minbak.web.categories;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Controller
@RequestMapping("/admin/categories")
public class CategoriesController {

    private final CategoriesService categoriesService;

    @Autowired
    public CategoriesController(CategoriesService categoriesService) {
        this.categoriesService = categoriesService;
    }

    // [R] 전체 카테고리 목록 조회
    @GetMapping
    public String showCategoriesList(Model model) {
        model.addAttribute("categories", categoriesService.getAllCategories());
        return "categories/categories-List";
    }

    // [C] 신규 카테고리 등록 폼 표시
    @GetMapping("/create")
    public String showCreateCategoryForm(Model model) {
        model.addAttribute("category", new CategoriesDto());
        return "categories/category-Create";
    }

    // [C] 신규 카테고리 등록 처리 (아이콘 URL 포함)
    @PostMapping
    public String createCategory(@ModelAttribute("category") CategoriesDto categoriesDto, Model model) {
        try {
            categoriesService.createCategory(categoriesDto);
            return "redirect:/admin/categories";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "categories/category-Create";
        }
    }

    // ✅ 카테고리 아이콘 URL만 변경 (AJAX 요청)
    @PutMapping("/{id}/icon")
    @ResponseBody
    public ResponseEntity<?> updateCategoryIcon(@PathVariable int id, @RequestBody Map<String, String> request) {
        String newIconUrl = request.get("categoryiconUrl");
        categoriesService.updateCategoryIcon(id, newIconUrl);
        return ResponseEntity.ok().body("아이콘이 업데이트되었습니다.");
    }

    // [U] 기존 카테고리 수정 폼 표시
    @GetMapping("/edit/{id}")
    public String showEditCategoryForm(@PathVariable int id, Model model) {
        CategoriesDto category = categoriesService.getCategoryById(id);
        model.addAttribute("category", category);
        return "categories/category-Update";
    }

    // [U] 카테고리 수정 처리 (아이콘 URL 포함)
    @PostMapping("/{id}")
    public String updateCategory(@PathVariable int id, @ModelAttribute("category") CategoriesDto categoriesDto) {
        categoriesDto.setCategoryId(id);
        categoriesService.updateCategory(categoriesDto);
        return "redirect:/admin/categories";
    }

    // [D] 카테고리 삭제 처리
    @PostMapping("/delete/{id}")
    public String deleteCategory(@PathVariable int id) {
        categoriesService.deleteCategory(id);
        return "redirect:/admin/categories";
    }


    // ✅ [U] 드래그 앤 드롭을 통한 카테고리 순서 변경 (AJAX 요청 처리)
    @PutMapping("/reorder")
    @ResponseBody
    public ResponseEntity<?> reorderCategories(@RequestBody Map<String, Integer> request) {
        int categoryId = request.get("categoryId");
        int newOrder = request.get("newOrder");

        categoriesService.changeCategoryOrder(categoryId, newOrder);

        return ResponseEntity.ok().body("카테고리 순서가 변경되었습니다.");
    }
}
