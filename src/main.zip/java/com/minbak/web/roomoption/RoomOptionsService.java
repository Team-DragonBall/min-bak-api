package com.minbak.web.roomoption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RoomOptionsService {
    private final RoomOptionsMapper roomOptionsMapper;

    @Autowired
    public RoomOptionsService(RoomOptionsMapper roomOptionsMapper) {
        this.roomOptionsMapper = roomOptionsMapper;
    }

    public List<RoomOptionsDto> getRoomsByAmenities(List<String> amenities) {
        if (amenities == null || amenities.isEmpty()) {
            return roomOptionsMapper.getAllRoomOptions();
        }
        return roomOptionsMapper.getRoomOptionsByAmenities(amenities, amenities.size());
    }

    public void addRoom(RoomOptionsDto room) {
        roomOptionsMapper.insertRoomOption(room);
    }

    public void updateRoom(RoomOptionsDto room) {
        roomOptionsMapper.updateRoomOption(room);
    }

    public void deleteRoom(int roomId) {
        roomOptionsMapper.deleteRoomOption(roomId);
    }

    // 특정 ID의 숙소 조회
    public RoomOptionsDto getRoomOptionById(int roomId) {
        return roomOptionsMapper.getRoomOptionById(roomId);
    }
}
