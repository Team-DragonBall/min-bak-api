package com.minbak.web.roomoption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin/roomOption")
public class RoomOptionsController {

    private final RoomOptionsService roomOptionsService;

    @Autowired
    public RoomOptionsController(RoomOptionsService roomOptionsService) {
        this.roomOptionsService = roomOptionsService;
    }

    // 편의시설 필터 적용된 숙소 리스트를 Thymeleaf에서 렌더링
    @GetMapping
    public String getRoomsByAmenities(@RequestParam(required = false) List<String> amenities, Model model) {
        List<RoomOptionsDto> rooms = roomOptionsService.getRoomsByAmenities(amenities != null ? amenities : List.of());
        model.addAttribute("rooms", rooms); // 모델에 숙소 리스트 추가
        return "roomOption/roomOption-list"; // Thymeleaf에서 사용할 HTML 파일명 (roomOption-list.html)
    }

    // 숙소 추가 페이지 이동
    @GetMapping("/create")
    public String showAddRoomForm() {
        return "roomOption/roomOption-create"; // 추가 페이지 (roomOption-create.html)
    }

    // 숙소 추가
    @PostMapping("/create")
    public String addRoom(@ModelAttribute RoomOptionsDto room) {
        roomOptionsService.addRoom(room);
        return "redirect:/admin/roomOption";
    }

    // 숙소 수정 페이지 이동
    @GetMapping("/update/{roomId}")
    public String showUpdateRoomForm(@PathVariable int roomId, Model model) {
        RoomOptionsDto room = roomOptionsService.getRoomOptionById(roomId);
        model.addAttribute("room", room);
        return "roomOption/roomOption-update";
    }

    // 숙소 업데이트
    @PutMapping("/{roomId}")
    public String updateRoom(@PathVariable int roomId, @ModelAttribute RoomOptionsDto room) {
        room.setRoomId(roomId);
        roomOptionsService.updateRoom(room);
        return "redirect:/admin/roomOption";
    }

    // 숙소 삭제
    @PostMapping("/delete/{roomId}")
    public String deleteRoom(@PathVariable int roomId) {
        roomOptionsService.deleteRoom(roomId);
        return "redirect:/admin/roomOption";
    }
}

