package com.minbak.web.roomoption;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;


@Mapper
public interface RoomOptionsMapper {

    // 사용자가 선택한 편의시설을 포함하는 숙소 리스트 조회
    List<RoomOptionsDto> getRoomOptionsByAmenities(@Param("amenities") List<String> amenities, @Param("size") int size);

    // 모든 숙소 조회
    List<RoomOptionsDto> getAllRoomOptions();

    // 숙소 추가
    void insertRoomOption(RoomOptionsDto room);

    // 숙소 업데이트
    void updateRoomOption(RoomOptionsDto room);

    // 숙소 삭제
    void deleteRoomOption(@Param("roomId") int roomId);

    // 특정 ID의 숙소 조회
    RoomOptionsDto getRoomOptionById(@Param("roomId") int roomId);
}

